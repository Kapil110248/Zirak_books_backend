import prisma from "../services/prismaClient.js";
import cloudinary from "../config/cloudinary.js";

// ✅ CREATE Customer
export const createCustomer = async (req, res) => {
  try {
    const data = req.body;
    if (!data.name_english) {
      return res.status(400).json({ success: false, message: "Customer name (English) is required" });
    }

    // File upload URLs from Multer
    if (req.files) {
      if (req.files.id_card_image?.[0]) {
        data.id_card_image = req.files.id_card_image[0].path;
      }
      if (req.files.any_file?.[0]) {
        data.any_file = req.files.any_file[0].path;
      }
    }

    const customer = await prisma.customers.create({ data });
    res.status(201).json({ success: true, message: "Customer created successfully", data: customer });
  } catch (err) {
    console.error("❌ Error creating customer:", err);
    res.status(500).json({ success: false, message: "Internal Server Error", error: err.message });
  }
};

// ✅ UPDATE Customer
export const updateCustomer = async (req, res) => {
  try {
    const { id } = req.params;
    const data = req.body;

    const existingCustomer = await prisma.customers.findUnique({
      where: { id: BigInt(id) },
    });
    if (!existingCustomer) {
      return res.status(404).json({ success: false, message: "Customer not found" });
    }

    // Upload updated files if provided
    if (req.files) {
      if (req.files.id_card_image?.[0]) {
        data.id_card_image = req.files.id_card_image[0].path;
      }
      if (req.files.any_file?.[0]) {
        data.any_file = req.files.any_file[0].path;
      }
    }

    const updatedCustomer = await prisma.customers.update({
      where: { id: BigInt(id) },
      data,
    });

    res.status(200).json({ success: true, message: "Customer updated successfully", data: updatedCustomer });
  } catch (err) {
    console.error("❌ Error updating customer:", err);
    res.status(500).json({ success: false, message: "Internal Server Error", error: err.message });
  }
};
